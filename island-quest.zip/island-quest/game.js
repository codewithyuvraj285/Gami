/* ============================================================
   ISLAND QUEST — a small mobile-first 2D exploration game
   Vanilla JS + Canvas2D. No external assets. No frameworks.
   ============================================================ */

// Register the service worker for offline play + installability.
// file:// pages and browsers without support simply skip this.
if ("serviceWorker" in navigator && (location.protocol === "http:" || location.protocol === "https:")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => { /* offline support unavailable — game still works */ });
  });
}

(function () {
  "use strict";

  /* ---------------------------------------------------------
     CONSTANTS & WORLD SETUP
  --------------------------------------------------------- */
  const TILE = 32;
  const COLS = 42;
  const ROWS = 32;
  const WORLD_W = COLS * TILE;
  const WORLD_H = ROWS * TILE;
  const SAVE_KEY = "islandquest_save_v1";
  const MAX_HEALTH = 5;
  const PLAYER_SPEED = 148; // px/sec
  const INTERACT_RANGE = 46;
  const PICKUP_RANGE = 22;

  // Seeded PRNG so decorative layout (trees/rocks) is stable within/between sessions.
  function mulberry32(seed) {
    return function () {
      seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rng = mulberry32(1337);

  /* ---------------------------------------------------------
     TERRAIN CLASSIFICATION
  --------------------------------------------------------- */
  // Regions used by classify() and by object placement below.
  const REGION = {
    forest: { x0: 22, y0: 2, x1: 41, y1: 21 },
    cave: { x0: 33, y0: 3, x1: 40, y1: 9 },
    village: { x0: 2, y0: 14, x1: 17, y1: 24 },
    cove: { x0: 29, y0: 22, x1: 40, y1: 29 },
  };

  function inRect(x, y, r) { return x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1; }

  function classify(x, y) {
    let t = "grass";
    // north/west sea edges
    if (y <= 0) t = "water";
    else if (y === 1) t = "sand";
    if (x <= 0) t = "water";
    else if (x === 1 && t !== "water") t = "sand";
    // south sea edge
    if (y >= 30) t = "water";
    else if (y >= 27 && y <= 29) t = "sand";
    // east sea edge
    if (x >= 41) t = "water";
    else if (x === 40) t = "sand";
    // cove peninsula overrides south-east water/sand
    if (inRect(x, y, REGION.cove)) {
      t = "sand";
    }
    // water gap between beach and cove (crossed by a bridge)
    if (y >= 23 && y <= 26 && x >= 27 && x <= 28) t = "water";
    if (y === 25 && x >= 27 && x <= 28) t = "bridge";
    // cave room
    if (inRect(x, y, REGION.cave)) t = "cave";
    return t;
  }

  const terrain = [];
  for (let y = 0; y < ROWS; y++) {
    const row = [];
    for (let x = 0; x < COLS; x++) row.push(classify(x, y));
    terrain.push(row);
  }
  function tileAt(px, py) {
    const tx = Math.floor(px / TILE), ty = Math.floor(py / TILE);
    if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) return "water";
    return terrain[ty][tx];
  }

  /* ---------------------------------------------------------
     STATIC WORLD OBJECTS (houses, trees, rocks, gate, decor)
  --------------------------------------------------------- */
  const houses = [
    { x: 3 * TILE, y: 15 * TILE, w: 4 * TILE, h: 3 * TILE, roof: "#e8623f" },
    { x: 10 * TILE, y: 15 * TILE, w: 4 * TILE, h: 3 * TILE, roof: "#3f9e5c" },
    { x: 6 * TILE, y: 20 * TILE, w: 4 * TILE, h: 3 * TILE, roof: "#5aa7d9" },
  ];

  const noTreeZones = [
    { x: 25 * TILE, y: 12 * TILE, r: 90 }, // near key
    { x: 34 * TILE, y: 8 * TILE, r: 110 }, // cave entrance
    { x: 22 * TILE, y: 6 * TILE, r: 70 },
  ];
  // Guarantee a walkable east-west corridor through the forest at the key's
  // row so scattered trees can never fully wall the player off from an area.
  for (let cx = 18; cx <= 41; cx += 3) {
    noTreeZones.push({ x: cx * TILE, y: 12 * TILE, r: 55 });
  }
  function inExclusion(x, y, zones) {
    return zones.some((z) => Math.hypot(x - z.x, y - z.y) < z.r);
  }

  const trees = [];
  const rocks = [];
  for (let y = REGION.forest.y0; y <= REGION.forest.y1; y++) {
    for (let x = REGION.forest.x0; x <= REGION.forest.x1; x++) {
      if (inRect(x, y, REGION.cave)) continue;
      if (terrain[y][x] === "water") continue;
      const wx = x * TILE + TILE / 2, wy = y * TILE + TILE / 2;
      if (inExclusion(wx, wy, noTreeZones)) continue;
      const roll = rng();
      if (roll < 0.14) {
        trees.push({ x: wx, y: wy, size: 16 + rng() * 8, sway: rng() * Math.PI * 2 });
      } else if (roll < 0.17) {
        rocks.push({ x: wx, y: wy, size: 9 + rng() * 6 });
      }
    }
  }
  // a few beach rocks for texture
  for (let i = 0; i < 10; i++) {
    const x = (26 + rng() * 13) * TILE, y = (27 + rng() * 2) * TILE;
    rocks.push({ x, y, size: 8 + rng() * 5 });
  }

  // Cave "gate" — a barrier blocking the single approach to the cave until unlocked
  const gate = { x: 33 * TILE, y: 8 * TILE, w: TILE, h: TILE * 2, type: "gate" };

  // House obstacle rects
  const obstacles = [];
  houses.forEach((h) => obstacles.push({ x: h.x, y: h.y, w: h.w, h: h.h, type: "house" }));
  trees.forEach((t) => obstacles.push({ x: t.x - t.size * 0.55, y: t.y - t.size * 0.4, w: t.size * 1.1, h: t.size * 0.9, type: "tree" }));
  rocks.forEach((r) => obstacles.push({ x: r.x - r.size * 0.8, y: r.y - r.size * 0.6, w: r.size * 1.6, h: r.size * 1.2, type: "rock" }));
  obstacles.push({ x: gate.x, y: gate.y, w: gate.w, h: gate.h, type: "gate" });

  function rectsOverlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function waterBlocked(rect) {
    const x0 = Math.floor(rect.x / TILE), x1 = Math.floor((rect.x + rect.w) / TILE);
    const y0 = Math.floor(rect.y / TILE), y1 = Math.floor((rect.y + rect.h) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) return true;
        if (terrain[ty][tx] === "water") return true;
      }
    }
    return false;
  }
  function obstacleBlocked(rect) {
    for (const o of obstacles) {
      if (o.type === "gate" && state.flags.caveUnlocked) continue;
      if (rectsOverlap(rect, o)) return true;
    }
    return false;
  }
  // The whole cave room is sealed off until the quest reward unlocks it —
  // this keeps players from sneaking in around the visual gate barrier.
  function caveLockBlocked(rect) {
    if (state.flags.caveUnlocked) return false;
    const x0 = Math.floor(rect.x / TILE), x1 = Math.floor((rect.x + rect.w) / TILE);
    const y0 = Math.floor(rect.y / TILE), y1 = Math.floor((rect.y + rect.h) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) continue;
        if (terrain[ty][tx] === "cave") return true;
      }
    }
    return false;
  }

  /* ---------------------------------------------------------
     COLLECTIBLES & NPCs (fixed positions -> stable save ids)
  --------------------------------------------------------- */
  const coinDefs = [
    [6, 17], [8, 22], [12, 18], [4, 19], [14, 21], // village
    [3, 26], [7, 27], [11, 28], [16, 26], [20, 27], // beach
    [24, 10], [27, 6], [30, 14], [26, 17], [33, 12], [37, 15], [23, 18], [29, 9], // forest
    [35, 5], [38, 7], [36, 4], // cave
    [32, 24], [35, 26], [38, 25], [34, 27], // cove
    [18, 14], [19, 8], [21, 22], [9, 12], [16, 10],
  ].map(([x, y], i) => ({ id: "c" + i, x: x * TILE + TILE / 2, y: y * TILE + TILE / 2, taken: false }));

  const heartDefs = [
    [31, 8], [22, 15],
  ].map(([x, y], i) => ({ id: "h" + i, x: x * TILE + TILE / 2, y: y * TILE + TILE / 2, taken: false }));

  const keyItem = { x: 25 * TILE + TILE / 2, y: 12 * TILE + TILE / 2, taken: false };

  const chest = {
    x: 35 * TILE, y: 25 * TILE, w: TILE, h: TILE,
    open: false, opening: false, lidAngle: 0,
  };

  const npcs = [
    {
      id: "elder", x: 7 * TILE + TILE / 2, y: 18 * TILE + TILE / 2,
      shirt: "#5aa7d9", accent: "#e9e9e9", name: "Old Maren",
    },
    {
      id: "fisherman", x: 9 * TILE + TILE / 2, y: 26 * TILE + TILE / 2,
      shirt: "#f4c542", accent: "#3a2a1a", name: "Finn the Fisherman", idle: 0,
    },
  ];

  const enemies = [];
  const enemySpawns = [[27, 12], [32, 17], [37, 10]];
  enemySpawns.forEach(([x, y], i) => {
    enemies.push({
      id: "e" + i, x: x * TILE, y: y * TILE, homeX: x * TILE, homeY: y * TILE,
      vx: 0, vy: 0, timer: rng() * 2, phase: rng() * Math.PI * 2, radius: 11,
      hue: i % 2 === 0 ? "#4caf7d" : "#7b5fc9",
    });
  });

  /* ---------------------------------------------------------
     GAME STATE
  --------------------------------------------------------- */
  const state = {
    player: {
      x: 8 * TILE, y: 18 * TILE, w: 20, h: 22, facing: "down",
      moving: false, walkPhase: 0, invuln: 0,
    },
    health: MAX_HEALTH,
    coins: 0,
    inventory: {}, // { key: 1, map: 1 }
    flags: { talkedToElder: false, hasKey: false, chestOpened: false, caveUnlocked: false },
    paused: false,
    dialogue: null, // { name, lines, index, onDone }
    soundOn: true,
    fisherIdle: 0,
    damageFlashUntil: 0,
    defeatCooldown: 0,
  };

  /* ---------------------------------------------------------
     AUDIO — tiny WebAudio synth, no external files
  --------------------------------------------------------- */
  let audioCtx = null;
  function ensureAudio() {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
      catch (e) { audioCtx = null; }
    } else if (audioCtx.state === "suspended") {
      audioCtx.resume();
    }
  }
  function tone(freq, dur, type, delay, vol) {
    if (!state.soundOn || !audioCtx) return;
    const t0 = audioCtx.currentTime + (delay || 0);
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type || "sine";
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(vol || 0.14, t0 + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(gain).connect(audioCtx.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }
  const sfx = {
    coin: () => { tone(880, 0.09, "triangle", 0, 0.12); tone(1320, 0.09, "triangle", 0.05, 0.1); },
    click: () => tone(320, 0.05, "square", 0, 0.06),
    damage: () => tone(140, 0.18, "sawtooth", 0, 0.14),
    chest: () => { tone(440, 0.12, "sine", 0, 0.14); tone(554, 0.12, "sine", 0.09, 0.14); tone(659, 0.2, "sine", 0.18, 0.14); },
    quest: () => { tone(660, 0.14, "sine", 0, 0.12); tone(880, 0.22, "sine", 0.12, 0.12); },
    heal: () => tone(520, 0.14, "sine", 0, 0.1),
    key: () => { tone(700, 0.08, "triangle", 0, 0.12); tone(1000, 0.14, "triangle", 0.07, 0.12); },
    locked: () => tone(180, 0.12, "square", 0, 0.08),
    hurt2: () => tone(100, 0.25, "sawtooth", 0, 0.12),
  };

  /* ---------------------------------------------------------
     SAVE / LOAD
  --------------------------------------------------------- */
  function saveGame() {
    try {
      const data = {
        px: state.player.x, py: state.player.y,
        health: state.health, coins: state.coins,
        inventory: state.inventory, flags: state.flags,
        coinsTaken: coinDefs.filter((c) => c.taken).map((c) => c.id),
        heartsTaken: heartDefs.filter((h) => h.taken).map((h) => h.id),
        keyTaken: keyItem.taken, chestOpen: chest.open,
        soundOn: state.soundOn,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch (e) { /* storage unavailable — fail silently */ }
  }
  function loadGame() {
    let raw;
    try { raw = localStorage.getItem(SAVE_KEY); } catch (e) { return false; }
    if (!raw) return false;
    try {
      const d = JSON.parse(raw);
      state.player.x = d.px ?? state.player.x;
      state.player.y = d.py ?? state.player.y;
      state.health = d.health ?? MAX_HEALTH;
      state.coins = d.coins ?? 0;
      state.inventory = d.inventory || {};
      state.flags = Object.assign(state.flags, d.flags || {});
      (d.coinsTaken || []).forEach((id) => { const c = coinDefs.find((x) => x.id === id); if (c) c.taken = true; });
      (d.heartsTaken || []).forEach((id) => { const h = heartDefs.find((x) => x.id === id); if (h) h.taken = true; });
      keyItem.taken = !!d.keyTaken;
      chest.open = !!d.chestOpen;
      if (typeof d.soundOn === "boolean") state.soundOn = d.soundOn;
      return true;
    } catch (e) { return false; }
  }
  function hasSave() {
    try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; }
  }
  function clearSave() {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* noop */ }
  }

  /* ---------------------------------------------------------
     DOM REFS
  --------------------------------------------------------- */
  const $ = (id) => document.getElementById(id);
  const screenStart = $("screen-start");
  const screenHowto = $("screen-howto");
  const screenGame = $("screen-game");
  const canvas = $("game-canvas");
  const ctx = canvas.getContext("2d");
  const heartsEl = $("hearts");
  const coinCountEl = $("coin-count");
  const questTextEl = $("quest-text");
  const toastEl = $("toast");
  const dialogueBox = $("dialogue-box");
  const dialogueName = $("dialogue-name");
  const dialogueText = $("dialogue-text");
  const dialogueNext = $("dialogue-next");
  const modalInventory = $("modal-inventory");
  const modalQuest = $("modal-quest");
  const modalPause = $("modal-pause");
  const modalComplete = $("modal-complete");
  const inventoryGrid = $("inventory-grid");
  const inventoryEmpty = $("inventory-empty");
  const questLogBody = $("quest-log-body");

  function resizeCanvas() {
    canvas.width = window.innerWidth * (window.devicePixelRatio || 1);
    canvas.height = window.innerHeight * (window.devicePixelRatio || 1);
    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";
  }
  window.addEventListener("resize", resizeCanvas);
  resizeCanvas();

  /* ---------------------------------------------------------
     INPUT — keyboard
  --------------------------------------------------------- */
  const keys = {};
  window.addEventListener("keydown", (e) => {
    keys[e.key.toLowerCase()] = true;
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    if (e.key === "Escape") togglePause();
    if (e.key === " " || e.key === "Enter") handleInteractPress();
  });
  window.addEventListener("keyup", (e) => { keys[e.key.toLowerCase()] = false; });

  function keyboardVector() {
    let dx = 0, dy = 0;
    if (keys["a"] || keys["arrowleft"]) dx -= 1;
    if (keys["d"] || keys["arrowright"]) dx += 1;
    if (keys["w"] || keys["arrowup"]) dy -= 1;
    if (keys["s"] || keys["arrowdown"]) dy += 1;
    return { dx, dy };
  }

  /* ---------------------------------------------------------
     INPUT — virtual joystick (touch + mouse fallback)
  --------------------------------------------------------- */
  const joyZone = $("joystick-zone");
  const joyThumb = $("joystick-thumb");
  const joystick = { active: false, dx: 0, dy: 0, id: null };
  const JOY_RADIUS = 46;

  function joyStart(clientX, clientY, id) {
    joystick.active = true; joystick.id = id;
    updateJoy(clientX, clientY);
  }
  function updateJoy(clientX, clientY) {
    const rect = joyZone.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    let dx = clientX - cx, dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > JOY_RADIUS) { dx = (dx / dist) * JOY_RADIUS; dy = (dy / dist) * JOY_RADIUS; }
    joyThumb.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    joystick.dx = dist > 6 ? dx / JOY_RADIUS : 0;
    joystick.dy = dist > 6 ? dy / JOY_RADIUS : 0;
  }
  function joyEnd() {
    joystick.active = false; joystick.dx = 0; joystick.dy = 0; joystick.id = null;
    joyThumb.style.transform = "translate(-50%,-50%)";
  }
  joyZone.addEventListener("touchstart", (e) => {
    e.preventDefault();
    const t = e.changedTouches[0];
    joyStart(t.clientX, t.clientY, t.identifier);
  }, { passive: false });
  joyZone.addEventListener("touchmove", (e) => {
    e.preventDefault();
    for (const t of e.changedTouches) if (t.identifier === joystick.id) updateJoy(t.clientX, t.clientY);
  }, { passive: false });
  window.addEventListener("touchend", (e) => {
    for (const t of e.changedTouches) if (t.identifier === joystick.id) joyEnd();
  });
  window.addEventListener("touchcancel", () => joyEnd());
  // mouse fallback for desktop testing by dragging the joystick
  joyZone.addEventListener("mousedown", (e) => { joyStart(e.clientX, e.clientY, "mouse"); });
  window.addEventListener("mousemove", (e) => { if (joystick.active && joystick.id === "mouse") updateJoy(e.clientX, e.clientY); });
  window.addEventListener("mouseup", () => { if (joystick.id === "mouse") joyEnd(); });

  /* ---------------------------------------------------------
     BUTTONS
  --------------------------------------------------------- */
  function onTap(el, fn) {
    let handled = false;
    el.addEventListener("touchstart", (e) => { e.preventDefault(); handled = true; fn(); }, { passive: false });
    el.addEventListener("click", () => { if (handled) { handled = false; return; } fn(); });
  }

  onTap($("btn-play"), () => { ensureAudio(); startNewGame(); });
  onTap($("btn-continue"), () => { ensureAudio(); continueGame(); });
  onTap($("btn-howto"), () => { screenHowto.classList.remove("hidden"); });
  onTap($("btn-howto-close"), () => { screenHowto.classList.add("hidden"); });
  onTap($("btn-sound-toggle"), () => toggleSound());
  onTap($("btn-sound-toggle-2"), () => toggleSound());
  onTap($("btn-pause"), () => togglePause());
  onTap($("btn-resume"), () => togglePause());
  onTap($("btn-inventory"), () => openModal(modalInventory, renderInventory));
  onTap($("btn-quest-log"), () => { togglePause(); openModal(modalQuest, renderQuestLog); });
  onTap($("btn-interact"), () => handleInteractPress());
  onTap($("btn-restart"), () => {
    if (confirm("Restart the game? Your progress will be reset.")) {
      clearSave();
      window.location.reload();
    }
  });
  onTap($("btn-complete-continue"), () => { modalComplete.classList.add("hidden"); state.paused = false; });
  onTap(dialogueNext, () => advanceDialogue());
  document.querySelectorAll("[data-close]").forEach((btn) => {
    onTap(btn, () => { $(btn.getAttribute("data-close")).classList.add("hidden"); state.paused = false; });
  });

  function toggleSound() {
    state.soundOn = !state.soundOn;
    const label = (state.soundOn ? "🔊 Sound on" : "🔇 Sound off");
    const label2 = (state.soundOn ? "🔊 On" : "🔇 Off");
    $("btn-sound-toggle").textContent = label;
    $("btn-sound-toggle-2").textContent = label2;
    if (state.soundOn) ensureAudio();
    saveGame();
  }

  function openModal(modal, renderFn) {
    ensureAudio(); sfx.click();
    if (renderFn) renderFn();
    modal.classList.remove("hidden");
    state.paused = true;
  }
  function togglePause() {
    if (!screenGame.classList.contains("hidden") && !state.dialogue) {
      ensureAudio(); sfx.click();
      const isHidden = modalPause.classList.contains("hidden");
      modalPause.classList.toggle("hidden");
      state.paused = isHidden;
      if (isHidden) saveGame();
    }
  }

  /* ---------------------------------------------------------
     GAME START / RESUME
  --------------------------------------------------------- */
  function refreshStartButtons() {
    if (hasSave()) { $("btn-continue").style.display = "block"; }
  }
  refreshStartButtons();

  function goToGameScreen() {
    screenStart.classList.add("hidden");
    screenGame.classList.remove("hidden");
    state.paused = false;
    updateHUD();
    lastTime = performance.now();
    requestAnimationFrame(loop);
  }
  function startNewGame() {
    clearSave();
    goToGameScreen();
    showToast("Welcome to the island! Find Old Maren in the village.");
  }
  function continueGame() {
    loadGame();
    goToGameScreen();
    updateHUD();
  }

  /* ---------------------------------------------------------
     TOAST
  --------------------------------------------------------- */
  let toastTimer = null;
  function showToast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.add("hidden"), 2400);
  }

  /* ---------------------------------------------------------
     QUEST TEXT / LOG
  --------------------------------------------------------- */
  function questText() {
    const f = state.flags;
    if (!f.talkedToElder) return "Meet the villager waving for help";
    if (!f.hasKey) return "Search the forest for the lost key";
    if (!f.chestOpened) return "Bring the key to the chest at the cove";
    return "Explore freely — the cave is open!";
  }
  function updateHUD() {
    heartsEl.textContent = "❤".repeat(state.health) + "♡".repeat(Math.max(0, MAX_HEALTH - state.health));
    coinCountEl.textContent = String(state.coins);
    questTextEl.textContent = questText();
  }
  function renderQuestLog() {
    const f = state.flags;
    const status = !f.talkedToElder ? "In Progress" : !f.hasKey ? "In Progress" : !f.chestOpened ? "In Progress" : "Complete";
    questLogBody.innerHTML = `
      <div class="quest-log-entry">
        <div class="quest-log-title">The Lost Key</div>
        <div>${questText()}</div>
        <div class="quest-log-done">${status}</div>
      </div>
    `;
  }
  function renderInventory() {
    const entries = Object.entries(state.inventory).filter(([, v]) => v > 0);
    inventoryGrid.innerHTML = "";
    inventoryEmpty.classList.toggle("hidden", entries.length > 0);
    const ICONS = { key: "🗝️", map: "🗺️" };
    const NAMES = { key: "Forest Key", map: "Ancient Map" };
    entries.forEach(([k, v]) => {
      const div = document.createElement("div");
      div.className = "inv-item";
      div.innerHTML = `<div>${ICONS[k] || "❔"}</div><div class="inv-name">${NAMES[k] || k}</div><div class="inv-count">${v}</div>`;
      inventoryGrid.appendChild(div);
    });
  }

  /* ---------------------------------------------------------
     DIALOGUE
  --------------------------------------------------------- */
  function openDialogue(name, lines, onDone) {
    state.dialogue = { name, lines, index: 0, onDone };
    dialogueName.textContent = name;
    dialogueText.textContent = lines[0];
    dialogueBox.classList.remove("hidden");
  }
  function advanceDialogue() {
    ensureAudio(); sfx.click();
    const d = state.dialogue;
    if (!d) return;
    d.index++;
    if (d.index >= d.lines.length) {
      dialogueBox.classList.add("hidden");
      const onDone = d.onDone;
      state.dialogue = null;
      if (onDone) onDone();
    } else {
      dialogueText.textContent = d.lines[d.index];
    }
  }

  /* ---------------------------------------------------------
     INTERACTION LOGIC
  --------------------------------------------------------- */
  function handleInteractPress() {
    if (state.dialogue) { advanceDialogue(); return; }
    if (state.paused) return;
    ensureAudio();
    const p = state.player;
    const px = p.x, py = p.y;

    // nearest NPC
    let target = null, bestDist = INTERACT_RANGE;
    for (const n of npcs) {
      const d = Math.hypot(n.x - px, n.y - py);
      if (d < bestDist) { bestDist = d; target = { type: "npc", ref: n }; }
    }
    const dChest = Math.hypot((chest.x + TILE / 2) - px, (chest.y + TILE / 2) - py);
    if (dChest < INTERACT_RANGE && dChest < bestDist) { target = { type: "chest" }; bestDist = dChest; }

    if (!target) { showToast("Nothing to interact with here."); return; }

    if (target.type === "npc") talkTo(target.ref);
    else if (target.type === "chest") openChest();
  }

  function talkTo(npc) {
    sfx.click();
    if (npc.id === "elder") {
      const f = state.flags;
      if (!f.talkedToElder) {
        openDialogue(npc.name, [
          "Oh! A new face on the island.",
          "Someone locked our old treasure chest down at the cove, and the key has been lost in the forest for ages.",
          "Would you look for it? Head east into the trees.",
        ], () => {
          f.talkedToElder = true;
          updateHUD();
          showToast("Quest started: The Lost Key");
          sfx.quest();
          saveGame();
        });
      } else if (f.hasKey && !f.chestOpened) {
        openDialogue(npc.name, ["You found it! Wonderful. The chest is south-east at the cove, past the beach."], null);
      } else if (f.chestOpened) {
        openDialogue(npc.name, ["Thank you for opening the chest.", "I heard the old cave nearby finally creaked open too — go take a look!"], null);
      } else {
        openDialogue(npc.name, ["The forest key must be out there somewhere. Keep looking!"], null);
      }
    } else if (npc.id === "fisherman") {
      const lines = [
        "The tide's perfect today.",
        "Careful around the forest — the little slimes startle easily and bump into everyone.",
        "I heard there's treasure somewhere past the beach, south-east.",
        "Nice weather for exploring, isn't it?",
      ];
      openDialogue(npc.name, [lines[npc.idle % lines.length]], null);
      npc.idle++;
    }
  }

  function openChest() {
    if (chest.open) { showToast("The chest is empty now — but what a nice view."); return; }
    if (!state.inventory.key) { showToast("It's locked. Maybe the key is somewhere in the forest?"); sfx.locked(); return; }
    chest.opening = true;
    sfx.chest();
    setTimeout(() => {
      chest.open = true;
      chest.opening = false;
      state.coins += 30;
      state.inventory.map = (state.inventory.map || 0) + 1;
      state.flags.chestOpened = true;
      state.flags.caveUnlocked = true;
      updateHUD();
      saveGame();
      showToast("+30 coins, an Ancient Map!");
      setTimeout(() => {
        sfx.quest();
        $("complete-text").textContent = "You opened the old chest and found coins and an Ancient Map. Something nearby just unlocked — the cave to the north is open now!";
        modalComplete.classList.remove("hidden");
        state.paused = true;
      }, 500);
    }, 650);
  }

  /* ---------------------------------------------------------
     UPDATE LOOP
  --------------------------------------------------------- */
  let lastTime = 0;
  function loop(t) {
    const dt = Math.min(0.05, (t - lastTime) / 1000);
    lastTime = t;
    if (!state.paused && !state.dialogue) update(dt, t);
    render(t);
    requestAnimationFrame(loop);
  }

  function update(dt, t) {
    updatePlayer(dt);
    updateEnemies(dt, t);
    checkPickups();
    if (state.defeatCooldown > 0) state.defeatCooldown -= dt;
  }

  function updatePlayer(dt) {
    const p = state.player;
    let { dx, dy } = keyboardVector();
    if (joystick.active) { dx = joystick.dx; dy = joystick.dy; }
    const len = Math.hypot(dx, dy);
    if (len > 1) { dx /= len; dy /= len; }
    p.moving = len > 0.05;

    if (p.moving) {
      if (Math.abs(dx) > Math.abs(dy)) p.facing = dx > 0 ? "right" : "left";
      else p.facing = dy > 0 ? "down" : "up";
      p.walkPhase += dt * 10;
    }

    const moveX = dx * PLAYER_SPEED * dt;
    const moveY = dy * PLAYER_SPEED * dt;
    const hw = p.w / 2, hh = p.h / 2;

    if (moveX !== 0) {
      const nx = p.x + moveX;
      const rect = { x: nx - hw, y: p.y - hh + 6, w: p.w, h: hh };
      if (!waterBlocked(rect) && !obstacleBlocked(rect) && !caveLockBlocked(rect)) p.x = nx;
    }
    if (moveY !== 0) {
      const ny = p.y + moveY;
      const rect = { x: p.x - hw, y: ny - hh + 6, w: p.w, h: hh };
      if (!waterBlocked(rect) && !obstacleBlocked(rect) && !caveLockBlocked(rect)) p.y = ny;
    }
    p.x = Math.max(hw, Math.min(WORLD_W - hw, p.x));
    p.y = Math.max(hh, Math.min(WORLD_H - hh, p.y));

    if (p.invuln > 0) p.invuln -= dt;
  }

  function updateEnemies(dt, t) {
    if (state.defeatCooldown > 0) return;
    const p = state.player;
    for (const e of enemies) {
      e.timer -= dt;
      if (e.timer <= 0) {
        e.timer = 1.2 + rng() * 1.6;
        const ang = rng() * Math.PI * 2;
        e.vx = Math.cos(ang) * 30;
        e.vy = Math.sin(ang) * 30;
        if (rng() < 0.3) { e.vx = 0; e.vy = 0; }
      }
      let nx = e.x + e.vx * dt, ny = e.y + e.vy * dt;
      if (Math.hypot(nx - e.homeX, ny - e.homeY) > 70) { nx = e.x; ny = e.y; e.timer = 0; }
      e.x = nx; e.y = ny;

      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d < e.radius + 12 && p.invuln <= 0) {
        state.health = Math.max(0, state.health - 1);
        p.invuln = 1.2;
        state.damageFlashUntil = performance.now() + 160;
        sfx.damage();
        const ang = Math.atan2(p.y - e.y, p.x - e.x);
        state.player.x += Math.cos(ang) * 18;
        state.player.y += Math.sin(ang) * 18;
        updateHUD();
        if (state.health <= 0) handleDefeat();
      }
    }
  }

  function handleDefeat() {
    state.defeatCooldown = 1.5;
    sfx.hurt2();
    showToast("You feel dizzy... time for a little rest.");
    state.player.x = 8 * TILE; state.player.y = 18 * TILE;
    state.health = 3;
    updateHUD();
    saveGame();
  }

  function checkPickups() {
    const p = state.player;
    for (const c of coinDefs) {
      if (c.taken) continue;
      if (Math.hypot(c.x - p.x, c.y - p.y) < PICKUP_RANGE) {
        c.taken = true;
        state.coins += 1;
        sfx.coin();
        updateHUD();
        saveGame();
      }
    }
    for (const h of heartDefs) {
      if (h.taken) continue;
      if (Math.hypot(h.x - p.x, h.y - p.y) < PICKUP_RANGE) {
        h.taken = true;
        if (state.health < MAX_HEALTH) { state.health += 1; sfx.heal(); showToast("Health restored!"); }
        else { state.coins += 5; showToast("Full health — found 5 coins instead!"); sfx.coin(); }
        updateHUD();
        saveGame();
      }
    }
    if (!keyItem.taken && Math.hypot(keyItem.x - p.x, keyItem.y - p.y) < PICKUP_RANGE) {
      keyItem.taken = true;
      state.inventory.key = (state.inventory.key || 0) + 1;
      state.flags.hasKey = true;
      sfx.key();
      showToast("Found the Forest Key!");
      updateHUD();
      saveGame();
    }
  }

  /* ---------------------------------------------------------
     RENDER
  --------------------------------------------------------- */
  function render(t) {
    if (screenGame.classList.contains("hidden")) return;
    const dpr = window.devicePixelRatio || 1;
    const vw = canvas.width, vh = canvas.height;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const cssW = vw / dpr, cssH = vh / dpr;

    const p = state.player;
    let camX = p.x - cssW / 2, camY = p.y - cssH / 2;
    camX = Math.max(0, Math.min(WORLD_W - cssW, camX));
    camY = Math.max(0, Math.min(WORLD_H - cssH, camY));
    if (WORLD_W < cssW) camX = (WORLD_W - cssW) / 2;
    if (WORLD_H < cssH) camY = (WORLD_H - cssH) / 2;

    ctx.clearRect(0, 0, cssW, cssH);
    ctx.fillStyle = "#1b6b8e";
    ctx.fillRect(0, 0, cssW, cssH);

    ctx.save();
    ctx.translate(-camX, -camY);

    drawTerrain(camX, camY, cssW, cssH, t);
    drawGate(t);

    // gather y-sorted sprites
    const sprites = [];
    trees.forEach((tr) => sprites.push({ y: tr.y + tr.size, draw: () => drawTree(tr, t) }));
    rocks.forEach((r) => sprites.push({ y: r.y + r.size * 0.6, draw: () => drawRock(r) }));
    houses.forEach((h) => sprites.push({ y: h.y + h.h, draw: () => drawHouse(h) }));
    npcs.forEach((n) => sprites.push({ y: n.y + 14, draw: () => drawNPC(n, t) }));
    enemies.forEach((e) => sprites.push({ y: e.y + 10, draw: () => drawEnemy(e, t) }));
    coinDefs.forEach((c) => { if (!c.taken) sprites.push({ y: c.y, draw: () => drawCoin(c, t) }); });
    heartDefs.forEach((h) => { if (!h.taken) sprites.push({ y: h.y, draw: () => drawHeartPickup(h, t) }); });
    if (!keyItem.taken) sprites.push({ y: keyItem.y, draw: () => drawKeyItem(t) });
    sprites.push({ y: chest.y + chest.h, draw: () => drawChest(t) });
    sprites.push({ y: p.y + 12, draw: () => drawPlayer(p, t) });

    sprites.sort((a, b) => a.y - b.y);
    sprites.forEach((s) => s.draw());

    ctx.restore();

    // damage flash overlay
    if (performance.now() < state.damageFlashUntil) {
      ctx.fillStyle = "rgba(200,30,30,0.25)";
      ctx.fillRect(0, 0, cssW, cssH);
    }

    // interact prompt bubble
    drawInteractPrompt(camX, camY);
  }

  function drawInteractPrompt(camX, camY) {
    const p = state.player;
    let near = null;
    for (const n of npcs) if (Math.hypot(n.x - p.x, n.y - p.y) < INTERACT_RANGE) near = n;
    const dChest = Math.hypot((chest.x + TILE / 2) - p.x, (chest.y + TILE / 2) - p.y);
    let px, py;
    if (near) { px = near.x; py = near.y - 34; }
    else if (dChest < INTERACT_RANGE) { px = chest.x + TILE / 2; py = chest.y - 20; }
    else return;
    ctx.save();
    ctx.translate(-camX, -camY);
    ctx.font = "bold 16px sans-serif";
    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.shadowColor = "rgba(0,0,0,0.4)";
    ctx.shadowBlur = 3;
    ctx.fillText("👆", px, py);
    ctx.restore();
  }

  function drawTerrain(camX, camY, cssW, cssH, t) {
    const x0 = Math.max(0, Math.floor(camX / TILE));
    const x1 = Math.min(COLS - 1, Math.ceil((camX + cssW) / TILE));
    const y0 = Math.max(0, Math.floor(camY / TILE));
    const y1 = Math.min(ROWS - 1, Math.ceil((camY + cssH) / TILE));
    const wavePulse = 0.5 + 0.5 * Math.sin(t / 700);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const type = terrain[y][x];
        const px = x * TILE, py = y * TILE;
        let color = "#5cb86a";
        if (type === "grass") color = ((x + y) % 2 === 0) ? "#5cb86a" : "#57b364";
        else if (type === "sand") color = ((x + y) % 2 === 0) ? "#ecc985" : "#e7c078";
        else if (type === "water") {
          color = `rgb(${27 + wavePulse * 10}, ${107 + wavePulse * 18}, ${142 + wavePulse * 20})`;
        } else if (type === "bridge") color = "#b07a3e";
        else if (type === "cave") color = ((x + y) % 2 === 0) ? "#3a3f4a" : "#343842";
        ctx.fillStyle = color;
        ctx.fillRect(px, py, TILE, TILE);

        // subtle texture speckles (deterministic per-tile)
        if (type === "grass" || type === "sand") {
          const seedv = (x * 928371 + y * 12931) % 997;
          if (seedv % 5 === 0) {
            ctx.fillStyle = type === "grass" ? "rgba(60,140,70,0.35)" : "rgba(180,140,70,0.3)";
            const ox = (seedv % 20), oy = ((seedv * 3) % 20);
            ctx.fillRect(px + ox, py + oy, 3, 3);
          }
        }
        if (type === "bridge") {
          ctx.strokeStyle = "rgba(0,0,0,0.15)";
          ctx.lineWidth = 1;
          for (let i = 4; i < TILE; i += 8) { ctx.beginPath(); ctx.moveTo(px, py + i); ctx.lineTo(px + TILE, py + i); ctx.stroke(); }
        }
      }
    }

    // shoreline foam between sand/grass and water (simple pass)
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 2;
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        if (terrain[y][x] !== "water") continue;
        const px = x * TILE, py = y * TILE;
        const neighbors = [[0, -1], [0, 1], [-1, 0], [1, 0]];
        for (const [nx, ny] of neighbors) {
          const tx = x + nx, ty = y + ny;
          if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) continue;
          if (terrain[ty][tx] !== "water") {
            ctx.beginPath();
            if (nx === 0 && ny === -1) { ctx.moveTo(px, py); ctx.lineTo(px + TILE, py); }
            if (nx === 0 && ny === 1) { ctx.moveTo(px, py + TILE); ctx.lineTo(px + TILE, py + TILE); }
            if (nx === -1 && ny === 0) { ctx.moveTo(px, py); ctx.lineTo(px, py + TILE); }
            if (nx === 1 && ny === 0) { ctx.moveTo(px + TILE, py); ctx.lineTo(px + TILE, py + TILE); }
            ctx.stroke();
          }
        }
      }
    }
  }

  function drawGate(t) {
    if (state.flags.caveUnlocked) return;
    const g = gate;
    ctx.save();
    ctx.strokeStyle = "#8b5a2b";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(g.x, g.y); ctx.lineTo(g.x + g.w, g.y + g.h);
    ctx.moveTo(g.x + g.w, g.y); ctx.lineTo(g.x, g.y + g.h);
    ctx.stroke();
    ctx.fillStyle = "#d9ae5c";
    ctx.beginPath();
    ctx.arc(g.x + g.w / 2, g.y + g.h / 2, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#8b5a2b"; ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }

  function drawTree(tr, t) {
    const sway = Math.sin(t / 900 + tr.sway) * 1.5;
    ctx.save();
    ctx.translate(tr.x, tr.y);
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.beginPath(); ctx.ellipse(0, 4, tr.size * 0.6, tr.size * 0.22, 0, 0, Math.PI * 2); ctx.fill();
    // trunk
    ctx.fillStyle = "#8b5a2b";
    ctx.fillRect(-tr.size * 0.09, -tr.size * 0.2, tr.size * 0.18, tr.size * 0.5);
    // canopy
    ctx.translate(sway, 0);
    ctx.fillStyle = "#2c7a44";
    ctx.beginPath(); ctx.arc(-tr.size * 0.3, -tr.size * 0.55, tr.size * 0.55, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(tr.size * 0.32, -tr.size * 0.5, tr.size * 0.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#3f9e5c";
    ctx.beginPath(); ctx.arc(0, -tr.size * 0.85, tr.size * 0.6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawRock(r) {
    ctx.save();
    ctx.translate(r.x, r.y);
    ctx.fillStyle = "rgba(0,0,0,0.15)";
    ctx.beginPath(); ctx.ellipse(0, r.size * 0.5, r.size * 0.9, r.size * 0.3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#8f95a3";
    ctx.beginPath(); ctx.ellipse(0, 0, r.size, r.size * 0.75, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#b3b9c6";
    ctx.beginPath(); ctx.ellipse(-r.size * 0.25, -r.size * 0.2, r.size * 0.5, r.size * 0.35, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawHouse(h) {
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.15)";
    ctx.fillRect(h.x + 4, h.y + h.h - 6, h.w, 10);
    // walls
    ctx.fillStyle = "#f3e6c4";
    ctx.fillRect(h.x, h.y + h.h * 0.35, h.w, h.h * 0.65);
    // roof
    ctx.fillStyle = h.roof;
    ctx.beginPath();
    ctx.moveTo(h.x - 6, h.y + h.h * 0.4);
    ctx.lineTo(h.x + h.w / 2, h.y - h.h * 0.25);
    ctx.lineTo(h.x + h.w + 6, h.y + h.h * 0.4);
    ctx.closePath(); ctx.fill();
    // door
    ctx.fillStyle = "#8b5a2b";
    ctx.fillRect(h.x + h.w / 2 - 9, h.y + h.h - 22, 18, 22);
    // window
    ctx.fillStyle = "#bfe3f0";
    ctx.fillRect(h.x + 10, h.y + h.h * 0.55, 12, 12);
    ctx.fillRect(h.x + h.w - 22, h.y + h.h * 0.55, 12, 12);
    ctx.restore();
  }

  function drawCoin(c, t) {
    const bob = Math.sin(t / 300 + c.x) * 2;
    const spin = Math.abs(Math.cos(t / 260 + c.x));
    ctx.save();
    ctx.translate(c.x, c.y + bob);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.beginPath(); ctx.ellipse(0, 9, 7, 2.4, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ffc857";
    ctx.beginPath(); ctx.ellipse(0, 0, 7 * spin + 1, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#e8a93b";
    ctx.beginPath(); ctx.ellipse(0, 0, (7 * spin + 1) * 0.5, 4.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawHeartPickup(h, t) {
    const bob = Math.sin(t / 260 + h.x) * 2;
    const scale = 1 + Math.sin(t / 220 + h.x) * 0.08;
    ctx.save();
    ctx.translate(h.x, h.y + bob);
    ctx.scale(scale, scale);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.beginPath(); ctx.ellipse(0, 10, 7, 2.4, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ff5f7e";
    ctx.beginPath();
    ctx.moveTo(0, 7);
    ctx.bezierCurveTo(-10, -2, -6, -10, 0, -3);
    ctx.bezierCurveTo(6, -10, 10, -2, 0, 7);
    ctx.fill();
    ctx.restore();
  }

  function drawKeyItem(t) {
    const bob = Math.sin(t / 260) * 3;
    const glow = 0.5 + 0.5 * Math.sin(t / 180);
    ctx.save();
    ctx.translate(keyItem.x, keyItem.y + bob);
    // sparkle
    ctx.strokeStyle = `rgba(255,230,140,${glow})`;
    ctx.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      const a = (t / 500) + (i * Math.PI) / 2;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 14, Math.sin(a) * 14);
      ctx.lineTo(Math.cos(a) * 20, Math.sin(a) * 20);
      ctx.stroke();
    }
    ctx.rotate(Math.sin(t / 500) * 0.3);
    ctx.strokeStyle = "#ffc857"; ctx.lineWidth = 3; ctx.lineCap = "round";
    ctx.beginPath(); ctx.arc(-6, 0, 4, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-2, 0); ctx.lineTo(9, 0); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(6, 4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(9, 0); ctx.lineTo(9, 5); ctx.stroke();
    ctx.restore();
  }

  function drawChest(t) {
    ctx.save();
    ctx.translate(chest.x + TILE / 2, chest.y + TILE / 2);
    ctx.fillStyle = "rgba(0,0,0,0.2)";
    ctx.beginPath(); ctx.ellipse(0, 14, 16, 4, 0, 0, Math.PI * 2); ctx.fill();
    // base
    ctx.fillStyle = "#8b5a2b";
    ctx.fillRect(-15, -4, 30, 16);
    ctx.strokeStyle = "#5c3a1a"; ctx.lineWidth = 2; ctx.strokeRect(-15, -4, 30, 16);
    // lid
    let lidAngle = chest.open ? -0.95 : chest.opening ? -0.6 : 0;
    ctx.save();
    ctx.translate(-15, -4);
    ctx.rotate(lidAngle);
    ctx.fillStyle = "#a3703f";
    ctx.fillRect(0, -10, 30, 10);
    ctx.strokeStyle = "#5c3a1a"; ctx.lineWidth = 2; ctx.strokeRect(0, -10, 30, 10);
    ctx.restore();
    // lock / glow
    if (!chest.open) {
      ctx.fillStyle = state.inventory.key ? "#ffc857" : "#5c3a1a";
      ctx.fillRect(-4, -2, 8, 7);
    } else {
      const glow = 0.4 + 0.3 * Math.sin(t / 300);
      ctx.fillStyle = `rgba(255,230,140,${glow})`;
      ctx.beginPath(); ctx.ellipse(0, 0, 14, 6, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function drawNPC(n, t) {
    const bob = Math.sin(t / 500 + n.x) * 1.5;
    drawHumanoid(n.x, n.y + bob, n.shirt, "#f0c9a0", false, 0, "down", n.accent);
  }

  function drawEnemy(e, t) {
    const squash = 1 + Math.sin(t / 180 + e.phase) * 0.14;
    ctx.save();
    ctx.translate(e.x, e.y);
    ctx.fillStyle = "rgba(0,0,0,0.2)";
    ctx.beginPath(); ctx.ellipse(0, e.radius * 0.9, e.radius * 0.9, e.radius * 0.3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = e.hue;
    ctx.beginPath();
    ctx.ellipse(0, 0, e.radius * (2 - squash), e.radius * squash, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(-4, -2, 2.6, 0, Math.PI * 2); ctx.arc(4, -2, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#222";
    ctx.beginPath(); ctx.arc(-4, -2, 1.2, 0, Math.PI * 2); ctx.arc(4, -2, 1.2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawPlayer(p, t) {
    const bob = p.moving ? Math.abs(Math.sin(p.walkPhase)) * -2 : 0;
    const flash = p.invuln > 0 && Math.floor(t / 90) % 2 === 0;
    ctx.save();
    if (flash) ctx.globalAlpha = 0.45;
    drawHumanoid(p.x, p.y + bob, "#ff7a59", "#f6d3a3", p.moving, p.walkPhase, p.facing, "#2c3e50");
    ctx.restore();
  }

  function drawHumanoid(x, y, shirt, skin, moving, phase, facing, hairColor) {
    ctx.save();
    ctx.translate(x, y);
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.22)";
    ctx.beginPath(); ctx.ellipse(0, 15, 11, 4, 0, 0, Math.PI * 2); ctx.fill();

    const legOffset = moving ? Math.sin(phase) * 4 : 0;
    // legs
    ctx.fillStyle = "#2c3e50";
    ctx.fillRect(-7, 6 + Math.max(0, legOffset), 5, 9);
    ctx.fillRect(2, 6 + Math.max(0, -legOffset), 5, 9);
    // body
    ctx.fillStyle = shirt;
    ctx.beginPath();
    roundRect(ctx, -9, -8, 18, 18, 5);
    ctx.fill();
    // head
    ctx.fillStyle = skin;
    ctx.beginPath(); ctx.arc(0, -16, 9, 0, Math.PI * 2); ctx.fill();
    // hair
    ctx.fillStyle = hairColor || "#3a2a1a";
    ctx.beginPath(); ctx.arc(0, -20, 8.6, Math.PI, 0); ctx.fill();
    // eyes (direction-aware)
    ctx.fillStyle = "#222";
    let ex = 0, ey = -16;
    if (facing === "left") { ctx.beginPath(); ctx.arc(-3, ey, 1.4, 0, Math.PI * 2); ctx.fill(); }
    else if (facing === "right") { ctx.beginPath(); ctx.arc(3, ey, 1.4, 0, Math.PI * 2); ctx.fill(); }
    else if (facing === "up") { /* back of head, no face */ }
    else { ctx.beginPath(); ctx.arc(-3, ey, 1.3, 0, Math.PI * 2); ctx.arc(3, ey, 1.3, 0, Math.PI * 2); ctx.fill(); }
    ctx.restore();
  }

  function roundRect(c, x, y, w, h, r) {
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
  }

  /* ---------------------------------------------------------
     AUTOSAVE
  --------------------------------------------------------- */
  // Guard every autosave trigger on the game actually being active — otherwise
  // a reload/tab-close from the start screen would overwrite a real save with
  // default state.
  function isGameActive() { return !screenGame.classList.contains("hidden"); }
  setInterval(() => { if (isGameActive()) saveGame(); }, 6000);
  window.addEventListener("visibilitychange", () => { if (document.hidden && isGameActive()) saveGame(); });
  window.addEventListener("beforeunload", () => { if (isGameActive()) saveGame(); });

  /* ---------------------------------------------------------
     INITIAL SOUND LABEL SYNC
  --------------------------------------------------------- */
  $("btn-sound-toggle").textContent = "🔊 Sound on";
  $("btn-sound-toggle-2").textContent = "🔊 On";

})();
