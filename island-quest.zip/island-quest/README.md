# Island Quest

A relaxing mobile-first 2D island exploration game. Vanilla HTML/CSS/JS +
Canvas — no build step, no external assets, no frameworks.

## 1. Run it locally

You need a local static server (opening `index.html` directly with
`file://` works for a quick look, but the service worker / offline support
and installability only work over `http://`).

Pick any one of these from inside the `island-quest` folder:

```bash
# Python
python3 -m http.server 8080

# Node
npx serve .

# VS Code
# Right-click index.html -> "Open with Live Server"
```

Then open `http://localhost:8080` (or whichever port/tool you used) in
Chrome on your phone or desktop.

## 2. Install it on Android as a PWA

1. Deploy the folder somewhere reachable over HTTPS (GitHub Pages, Netlify,
   Vercel, Firebase Hosting, or your own server all work — HTTPS is
   required for the install prompt and service worker outside of
   `localhost`).
2. Open the URL in **Chrome on Android**.
3. Tap the **⋮** menu → **Install app** (or **Add to Home screen**). Chrome
   may also show an automatic "Install" banner/button.
4. The game launches full-screen from your home screen, works offline
   after the first load, and keeps your save in local storage.

## 3. Convert it to an APK later with Capacitor

The project is already structured as a plain static web app, which is what
Capacitor wraps:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Island Quest" "com.yourname.islandquest" --web-dir=.
npx cap add android
npx cap copy
npx cap open android
```

That last command opens the project in Android Studio, where you can hit
**Build → Build Bundle(s)/APK(s) → Build APK(s)**. The generated `www`
folder Capacitor expects is just this project's root (`index.html`,
`style.css`, `game.js`, `manifest.json`, `service-worker.js`, `icons/`) —
no changes needed since everything is already relative-pathed.

## How to play

- Move with the joystick (bottom-left) or WASD / arrow keys.
- Tap the hand button (bottom-right) to talk to villagers and open the chest.
- Walk over coins, hearts, and the forest key to pick them up automatically.
- Find Old Maren in the village to start the quest, search the forest for
  the lost key, then bring it to the chest at the south-east cove.
- Opening the chest unlocks the cave to the north — go explore it.
- Progress saves automatically (local storage) every few seconds and on
  pause/close.

## Files

```
index.html         all screens + HUD markup
style.css           mobile-first responsive styling
game.js              world, rendering, input, quests, save/load, audio
manifest.json        PWA manifest
service-worker.js    offline caching
icons/               app icons (192px, 512px)
```
